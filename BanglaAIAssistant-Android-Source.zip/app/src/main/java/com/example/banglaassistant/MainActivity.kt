package com.example.banglaassistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var output: TextView
    private lateinit var input: EditText
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            gravity = Gravity.TOP
        }
        page.addView(TextView(this).apply {
            text = "বাংলা AI Assistant"
            textSize = 26f
        })
        page.addView(TextView(this).apply {
            text = "বাংলায় লিখুন বা কথা বলুন"
            textSize = 16f
            setPadding(0, 12, 0, 12)
        })
        input = EditText(this).apply { hint = "আপনার কথা লিখুন..." }
        page.addView(input, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val actions = LinearLayout(this)
        val speak = Button(this).apply {
            text = "🎙 কথা বলুন"
            setOnClickListener { startVoiceInput() }
        }
        val send = Button(this).apply {
            text = "পাঠান"
            setOnClickListener { respond(input.text.toString()) }
        }
        actions.addView(speak, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(send, LinearLayout.LayoutParams(0, -2, 1f))
        page.addView(actions)

        output = TextView(this).apply {
            text = "এখানে উত্তর দেখা যাবে।"
            textSize = 18f
            setPadding(0, 24, 0, 24)
        }
        page.addView(output)

        page.addView(Button(this).apply {
            text = "BIG / SMALL বিশ্লেষণ"
            setOnClickListener { showBigSmall() }
        })
        page.addView(Button(this).apply {
            text = "ভাসমান বাটন চালু করুন"
            setOnClickListener {
                if (android.provider.Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, FloatingButtonService::class.java))
                    Toast.makeText(this@MainActivity, "ভাসমান বাটন চালু হয়েছে", Toast.LENGTH_SHORT).show()
                } else {
                    val i = Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                    startActivity(i)
                }
            }
        })
        setContentView(ScrollView(this).apply { addView(page) })
    }

    private fun startVoiceInput() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "বাংলায় বলুন")
        }
        try { startActivityForResult(i, 101) }
        catch (_: Exception) { Toast.makeText(this, "এই ফোনে Speech Recognition পাওয়া যাচ্ছে না", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Deprecated by Android API; kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            input.setText(words)
            respond(words)
        }
    }

    private fun respond(message: String) {
        if (message.isBlank()) return
        val answer = "তোমার কথা পেয়েছি: $message। এই প্রাথমিক সংস্করণে AI সার্ভার এখনো যুক্ত করা হয়নি।"
        output.text = answer
        if (ttsReady) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "bn_reply")
    }

    private fun showBigSmall() {
        val digits = EditText(this).apply {
            hint = "শেষ কয়েকটি ফল লিখুন (যেমন 2,7,9,1)"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30,20,30,20) }
        box.addView(digits)
        AlertDialog.Builder(this).setTitle("BIG / SMALL").setView(box)
            .setPositiveButton("বিশ্লেষণ") { _, _ ->
                val nums = digits.text.toString().split(",", " ", "，").mapNotNull { it.trim().toIntOrNull() }.filter { it in 0..9 }
                val big = nums.count { it >= 5 }
                val small = nums.count { it <= 4 }
                val msg = if (nums.isEmpty()) "০–৯ এর মধ্যে ফল লিখুন।"
                    else "মোট ${nums.size}টি ফল। BIG: $big, SMALL: $small। এটি শুধু আগের ফলের পরিসংখ্যান, নিশ্চিত ভবিষ্যদ্বাণী নয়।"
                output.text = msg
                if (ttsReady) tts.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "analysis")
            }.setNegativeButton("বন্ধ", null).show()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("bn", "BD"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
