# বাংলা AI Assistant (প্রাথমিক Android প্রকল্প)

ফিচার কাঠামো:
- বাংলা Speech Recognition intent (ডিভাইসের speech service নির্ভর)
- Android Text-to-Speech (ডিভাইসে বাংলা voice data থাকলে)
- BIG/SMALL: ৫–৯ BIG, ০–৪ SMALL; আগের ফলের পরিসংখ্যান, ভবিষ্যদ্বাণী নয়
- Overlay permission নিয়ে floating AI bubble

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- এই সোর্সে এখনো কোনো Gemini/OpenAI API বা backend যুক্ত নেই। তাই এটি এখন AI-র মতো জেনারেটিভ উত্তর দেয় না।
- Overlay service এবং microphone behavior বিভিন্ন TECNO/Android সংস্করণে বাস্তব ফোনে পরীক্ষা করতে হবে।
- APK তৈরি করতে Android Studio/Android SDK এবং Gradle লাগবে।
- minSdk 23; targetSdk 28 কেবল প্রাথমিক পরীক্ষার জন্য। প্রকাশের আগে target SDK আপডেট, foreground-service/notification আচরণ এবং Play policy যাচাই জরুরি।
