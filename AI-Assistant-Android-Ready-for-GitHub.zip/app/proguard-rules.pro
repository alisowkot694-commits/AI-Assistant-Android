# Keep JavaScript bridge methods exposed to the hosted assistant web app.
-keepclassmembers class com.aiassistant.app.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
