# AI Assistant — Android APK project

This project packages the hosted AI Assistant web app in an Android WebView and provides a native Android app-launch bridge plus a foreground wake-phrase service.

## Important behavior and limitations

- The hosted AI interface is loaded from the URL configured in `MainActivity.kt`. The actual web-app source is not included in this ZIP, so its availability and its Bengali/English conversational features depend on that hosted website.
- The wake phrase service listens for “AI Assistant” (including common Bengali-script renderings) using Android's speech-recognition service. It requires microphone permission and displays an ongoing foreground notification while active.
- Android 12–15 and phone manufacturers may restrict background microphone use or stop services to save battery. The user must grant microphone permission, and may need to allow background activity / unrestricted battery use in phone settings. No Android app can guarantee uninterrupted always-on listening on every device.
- Speech recognition may use Google's/another installed speech-recognition provider and may require internet. Recognition language behavior varies by device.
- The notification includes a **Stop listening** action.

## Build APK automatically with GitHub Actions

1. Upload the contents of this ZIP into the root of a GitHub repository (not the ZIP file itself).
2. Open the repository's **Actions** tab.
3. Select **Build AI Assistant APK** and press **Run workflow** (or push to `main`/`master`).
4. When the workflow succeeds, open that run and download the `AI-Assistant-debug-apk` artifact.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`, then install it on your Android phone.

The workflow uses JDK 17 and Gradle 8.7. This project does not require a locally installed Android Studio to use the GitHub build workflow.

## BIG / SMALL history-analysis bridge

The Android bridge now exposes two JavaScript methods to the hosted page as `AndroidBridge`:

- `AndroidBridge.classifyNumber(number)` returns `BIG` for 5–9, `SMALL` for 0–4, and `INVALID` otherwise.
- `AndroidBridge.analyzeBigSmallHistory("9,7,4,2,6")` returns JSON with the entered history, BIG/SMALL counts and percentages, latest result, current same-side streak, and a descriptive historical tendency. Results are interpreted oldest-to-newest (latest last).

The hosted web application's source is not part of this Android project. Its screen must call these bridge methods and present the returned analysis before the feature becomes visible in the app. Historical frequency is descriptive only and cannot guarantee the next 30-second result.

## Configurable BIG / SMALL number rules

The Android bridge exposes `getBigStartsAt()` and `setBigStartsAt(number)`. The default boundary is 5, so 0-4 are SMALL and 5-9 are BIG. To change the boundary later from the hosted web app, call `AndroidBridge.setBigStartsAt(6)` (for example); this persists on the device and changes both `classifyNumber()` and `analyzeBigSmallHistory()` immediately. Valid boundaries are 1 through 9. The analysis reports historical counts/frequencies and does not claim to predict or guarantee the next random result.
