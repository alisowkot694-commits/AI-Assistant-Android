package com.aiassistant.app

import org.json.JSONArray
import org.json.JSONObject

/** Configurable rules for the user's number game. Default: 0-4 SMALL, 5-9 BIG. */
object BigSmallAnalyzer {
    const val DEFAULT_BIG_STARTS_AT = 5

    fun category(number: Int, bigStartsAt: Int = DEFAULT_BIG_STARTS_AT): String {
        if (number !in 0..9 || bigStartsAt !in 1..9) return "INVALID"
        return if (number >= bigStartsAt) "BIG" else "SMALL"
    }

    /** Accepts comma/space-separated past results, newest result last. */
    fun analyze(history: String, bigStartsAt: Int = DEFAULT_BIG_STARTS_AT): JSONObject {
        val threshold = bigStartsAt.coerceIn(1, 9)
        val values = Regex("[0-9]+")
            .findAll(history)
            .mapNotNull { it.value.toIntOrNull()?.takeIf { n -> n in 0..9 } }
            .toList()
        val big = values.count { it >= threshold }
        val small = values.size - big
        val latest = values.lastOrNull()
        val latestSide = latest?.let { category(it, threshold) }
        val streak = if (latestSide == null) 0 else values.asReversed()
            .takeWhile { category(it, threshold) == latestSide }.count()
        val tendency = when {
            values.size < 5 -> "INSUFFICIENT_DATA"
            big > small -> "BIG_TREND_IN_HISTORY"
            small > big -> "SMALL_TREND_IN_HISTORY"
            else -> "BALANCED_HISTORY"
        }
        return JSONObject().apply {
            put("rule", "0-${threshold - 1}=SMALL,$threshold-9=BIG")
            put("bigStartsAt", threshold)
            put("results", JSONArray(values))
            put("total", values.size)
            put("bigCount", big)
            put("smallCount", small)
            put("bigPercent", if (values.isEmpty()) JSONObject.NULL else big * 100.0 / values.size)
            put("smallPercent", if (values.isEmpty()) JSONObject.NULL else small * 100.0 / values.size)
            put("latestNumber", latest ?: JSONObject.NULL)
            put("latestCategory", latestSide ?: JSONObject.NULL)
            put("currentStreak", streak)
            put("historicalTendency", tendency)
            put("notice", "Historical frequency is not a guarantee of the next result.")
        }
    }
}
