package com.aiassistant.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.content.SharedPreferences
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val appUrl = "https://ais-dev-wdllvgau2dxmeg42kjgdbp-698982768338.asia-northeast1.run.app"
    private val trustedHost = Uri.parse(appUrl).host
    private val permissionRequestCode = 1001
    private lateinit var gameSettings: SharedPreferences

    private fun bigStartsAt(): Int = gameSettings.getInt("big_starts_at", BigSmallAnalyzer.DEFAULT_BIG_STARTS_AT).coerceIn(1, 9)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        gameSettings = getSharedPreferences("big_small_settings", MODE_PRIVATE)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    return if (uri.scheme == "https" && uri.host == trustedHost) {
                        false
                    } else {
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW, uri))
                        } catch (_: Exception) { }
                        true
                    }
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        val originHost = request.origin.host
                        val audioOnly = request.resources.all { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }
                        if (request.origin.scheme == "https" && originHost == trustedHost && audioOnly &&
                            ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            request.grant(request.resources)
                        } else {
                            request.deny()
                        }
                    }
                }
            }
            addJavascriptInterface(AndroidBridge(), "AndroidBridge")
            loadUrl(appUrl)
        }
        setContentView(webView)
        requestRuntimePermissions()
    }

    private fun requestRuntimePermissions() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), permissionRequestCode)
        } else {
            startWakeServiceIfAllowed()
        }
    }

    @Deprecated("Deprecated in Android API, retained for compatibility with the project's minimum SDK")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequestCode &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startWakeServiceIfAllowed()
        }
    }

    private fun startWakeServiceIfAllowed() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        try {
            ContextCompat.startForegroundService(this, Intent(this, WakeWordService::class.java))
        } catch (_: Exception) {
            // Android may restrict microphone foreground-service startup in the background.
            // This call is made while the activity is visible, after the user grants permission.
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun openApp(packageName: String, fallbackUrl: String): Boolean {
            return try {
                val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launchIntent)
                    true
                } else if (fallbackUrl.isNotBlank()) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)))
                    true
                } else false
            } catch (_: Exception) { false }
        }

        @JavascriptInterface
        fun classifyNumber(number: Int): String {
            return BigSmallAnalyzer.category(number, bigStartsAt())
        }

        @JavascriptInterface
        fun analyzeBigSmallHistory(history: String): String {
            return BigSmallAnalyzer.analyze(history, bigStartsAt()).toString()
        }

        /** Change the BIG boundary later without rebuilding the app. 5 means 0-4 SMALL, 5-9 BIG. */
        @JavascriptInterface
        fun setBigStartsAt(number: Int): Boolean {
            if (number !in 1..9) return false
            return gameSettings.edit().putInt("big_starts_at", number).commit()
        }

        @JavascriptInterface
        fun getBigStartsAt(): Int = bigStartsAt()

        @JavascriptInterface
        fun startWakeService() {
            runOnUiThread { startWakeServiceIfAllowed() }
        }

        @JavascriptInterface
        fun stopWakeService() {
            stopService(Intent(this@MainActivity, WakeWordService::class.java))
        }
    }
}
