# New native Bangla AI Assistant
The new native Android project is in `android-native/`; it does not load a browser page. It includes Bengali speech recognition (device/provider dependent), Bengali text-to-speech (device voice data dependent), a BIG/SMALL historical-count analyzer, and an optional floating overlay button.

## Build
Run **Build Native Bangla AI Assistant APK** in GitHub Actions; download the `Bangla-AI-Assistant-debug-apk` artifact and extract the APK.

## AI backend
Deploy `backend/` as a Node.js 20+ service. Set `OPENAI_API_KEY` as a host secret, never in this repository or APK. Enter the deployed backend URL in the app's **সার্ভার** button. API usage may incur charges. AI chat requires the backend.

BIG/SMALL reports only supplied past outcomes; it does not predict or guarantee the next result. Floating overlay requires Android's “Display over other apps” permission.
