# Secure OpenAI backend
Deploy this folder as a Node.js 20+ web service. Start command: `npm start`. Add `OPENAI_API_KEY` in the hosting provider's secret/environment settings. Optional: set `OPENAI_MODEL` (default `gpt-5.5`).
The app's সার্ভার button expects the deployed service root URL and appends `/chat`. Test `/health` first. Never put the API key in the Android app, GitHub files, or chat messages.
