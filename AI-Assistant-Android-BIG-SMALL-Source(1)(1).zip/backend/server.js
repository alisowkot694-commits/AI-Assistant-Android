import express from "express";
const app = express();
app.use(express.json({ limit: "32kb" }));
app.get("/health", (_req, res) => res.json({ ok: true, service: "Bangla AI Assistant" }));
app.post("/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message || message.length > 6000) return res.status(400).json({ error: "message is required (max 6000 chars)" });
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "Server is not configured" });
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": "Bearer " + process.env.OPENAI_API_KEY, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-5.5",
        instructions: "You are a helpful Android voice assistant. Always reply in clear, natural Bengali when the user writes or speaks Bengali. Be concise and practical.",
        input: message
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(502).json({ error: "AI provider request failed", detail: data.error?.message || "Unknown upstream error" });
    const reply = (data.output || []).flatMap(x => x.content || []).filter(x => x.type === "output_text").map(x => x.text).join("\n").trim();
    return res.json({ reply: reply || "দুঃখিত, উত্তর তৈরি করা যায়নি।" });
  } catch (err) { return res.status(500).json({ error: "Server error", detail: String(err?.message || err) }); }
});
const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => console.log("Assistant backend listening on " + port));
