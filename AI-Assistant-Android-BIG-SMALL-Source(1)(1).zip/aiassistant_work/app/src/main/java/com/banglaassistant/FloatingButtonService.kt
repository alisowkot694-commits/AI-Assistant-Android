package com.banglaassistant

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class FloatingButtonService : Service() {
    private var window: WindowManager? = null
    private var bubble: TextView? = null
    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        window = getSystemService(WINDOW_SERVICE) as WindowManager
        bubble = TextView(this).apply {
            text = "AI"; textSize = 17f; setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF2168D2.toInt()); gravity = Gravity.CENTER; setPadding(18, 12, 18, 12)
            setOnClickListener {
                val i = Intent(this@FloatingButtonService, MainActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                startActivity(i)
            }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 260 }
        window?.addView(bubble, params)
    }
    override fun onDestroy() {
        try { if (bubble?.isAttachedToWindow == true) window?.removeView(bubble) } catch (_: Exception) {}
        bubble = null; window = null; super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
