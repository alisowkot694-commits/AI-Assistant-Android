package com.banglaassistant

import android.app.*
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var answer: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private val io = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("assistant", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 16)
            setBackgroundColor(Color.rgb(245, 248, 255))
        }
        root.addView(TextView(this).apply {
            text = "বাংলা AI Assistant"; textSize = 25f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(33, 104, 210))
        }, LinearLayout.LayoutParams(-1, 60))
        root.addView(TextView(this).apply {
            text = "বাংলায় বলুন বা লিখুন — AI উত্তর দেবে"; textSize = 15f; gravity = Gravity.CENTER
        })
        answer = TextView(this).apply {
            text = "স্বাগতম! নিচে লিখুন অথবা মাইক্রোফোন চাপুন।"
            textSize = 17f; setTextColor(Color.BLACK); setPadding(14, 16, 14, 16)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(ScrollView(this).apply { addView(answer) }, LinearLayout.LayoutParams(-1, 0, 1f))
        input = EditText(this).apply { hint = "এখানে লিখুন…"; textSize = 17f; minLines = 2 }
        root.addView(input)
        val row = LinearLayout(this)
        row.addView(Button(this).apply { text = "পাঠান"; setOnClickListener { askAI(input.text.toString()) } }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply { text = "🎙️ বাংলায় বলুন"; setOnClickListener { startVoice() } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)
        val tools = LinearLayout(this)
        tools.addView(Button(this).apply { text = "BIG/SMALL"; setOnClickListener { bigSmall() } }, LinearLayout.LayoutParams(0, -2, 1f))
        tools.addView(Button(this).apply { text = "ভাসমান বাটন"; setOnClickListener { enableBubble() } }, LinearLayout.LayoutParams(0, -2, 1f))
        tools.addView(Button(this).apply { text = "সার্ভার"; setOnClickListener { setServer() } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(tools)
        setContentView(root)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale("bn", "BD")
    }

    private fun startVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "বাংলায় বলুন")
        }
        try { startActivityForResult(intent, 410) } catch (_: Exception) { show("এই ফোনে ভয়েস ইনপুট সেবা পাওয়া যাচ্ছে না।") }
    }

    @Deprecated("Legacy speech result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 410 && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            input.setText(words)
            if (words.isNotBlank()) askAI(words)
        }
    }

    private fun askAI(message: String) {
        if (message.isBlank()) { show("আগে কিছু লিখুন বা বলুন।"); return }
        val endpoint = prefs.getString("endpoint", "")!!.trim()
        if (endpoint.isBlank()) { show("AI সার্ভার এখনো যুক্ত হয়নি। সার্ভার বাটনে ব্যাকএন্ড URL বসাতে হবে।"); return }
        show("উত্তর তৈরি হচ্ছে…")
        io.execute {
            try {
                val conn = URL(endpoint.trimEnd('/') + "/chat").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"; conn.connectTimeout = 15000; conn.readTimeout = 60000
                conn.doOutput = true; conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(JSONObject().put("message", message).toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                val reply = JSONObject(body).optString("reply", "উত্তর পাওয়া যায়নি।")
                runOnUiThread { show(reply); speak(reply) }
                conn.disconnect()
            } catch (e: Exception) { runOnUiThread { show("সার্ভারে সংযোগ হয়নি: " + (e.message ?: "নেটওয়ার্ক সমস্যা")) } }
        }
    }

    private fun bigSmall() {
        val field = EditText(this).apply { hint = "যেমন: 3, 8, 1, 6"; textSize = 16f }
        AlertDialog.Builder(this).setTitle("BIG/SMALL বিশ্লেষণ")
            .setMessage("আগের ফলাফল কমা দিয়ে লিখুন (০–৯)। ৫–৯ = BIG, ০–৪ = SMALL।")
            .setView(field).setPositiveButton("বিশ্লেষণ") { _, _ ->
                val nums = field.text.toString().split(",", " ", "،").mapNotNull { it.trim().toIntOrNull() }.filter { it in 0..9 }
                if (nums.isEmpty()) { show("সঠিক সংখ্যা পাওয়া যায়নি।"); return@setPositiveButton }
                val big = nums.count { it >= 5 }; val small = nums.size - big
                val trend = if (big > small) "BIG বেশি এসেছে" else if (small > big) "SMALL বেশি এসেছে" else "দুটিই সমান এসেছে"
                show("মোট " + nums.size + "টি ফলাফল\nBIG: " + big + "\nSMALL: " + small + "\n" + trend + "\n\nএটি অতীতের পরিসংখ্যান, পরের রাউন্ডের নিশ্চয়তা নয়।")
            }.setNegativeButton("বন্ধ", null).show()
    }

    private fun enableBubble() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
            show("পরের স্ক্রিনে ‘Allow display over other apps’ চালু করে ফিরে আসুন।")
        } else {
            startService(Intent(this, FloatingButtonService::class.java))
            show("ভাসমান AI বাটন চালু হয়েছে।")
        }
    }

    private fun setServer() {
        val field = EditText(this).apply { hint = "https://your-backend.example.com"; setText(prefs.getString("endpoint", "")); textSize = 15f }
        AlertDialog.Builder(this).setTitle("AI সার্ভার URL")
            .setMessage("নিরাপদ ব্যাকএন্ডের URL দিন। OpenAI API Key এখানে দেবেন না।")
            .setView(field).setPositiveButton("সংরক্ষণ") { _, _ ->
                prefs.edit().putString("endpoint", field.text.toString().trim()).apply()
                show("সার্ভার URL সংরক্ষণ হয়েছে।")
            }.setNegativeButton("বাতিল", null).show()
    }

    private fun show(text: String) { answer.text = text }
    private fun speak(text: String) { if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "reply") }
    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        io.shutdownNow()
        super.onDestroy()
    }
}
